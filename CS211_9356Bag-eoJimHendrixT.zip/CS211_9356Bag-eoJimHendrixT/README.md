# Data Structures Prelim Exercises
 
