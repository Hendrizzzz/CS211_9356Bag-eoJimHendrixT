package prelim;

public interface MyArrayList<T> extends MyList<T> {
    T get(int index);
    void set (int index, T object);
}
